WTEngine Demo

By:  Matthew Evans

See LICENSE.txt for copyright information

Keyboard commands:
 - WASD or arrow keys to move
 - CTRL to fire main weapon
 - ALT to activate the shield
 - ESC to open menus
